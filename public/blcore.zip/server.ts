import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", app: "BL Core Gestão" });
  });

  // Organize budget with Gemini AI
  app.post("/api/gemini/organize-budget", async (req, res) => {
    try {
      const { text, category, companyName, clientName } = req.body;

      if (!text || typeof text !== "string" || !text.trim()) {
        res.status(400).json({ error: "Texto ou áudio para o orçamento é obrigatório" });
        return;
      }

      const apiKey = process.env.GEMINI_API_KEY || "AQ.Ab8RN6I694aSrVyB6l5glBLPIeA6_7jcAOQ7cI_WNnaoHydk1A";

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      const systemInstruction = `Você é o especialista de elite em geração de orçamentos e propostas comerciais do sistema BL Core Gestão.
Sua missão é transformar qualquer texto informal (seja ditado por voz, seja digitado de forma rápida) em uma proposta comercial completa, profissional e detalhada.

DADOS DA EMPRESA:
- Categoria / Ramo: "${category || "Social Media"}"
- Nome da Empresa: "${companyName || "BL Core Gestão"}"

VOCÊ DEVE OBRIGATORIAMENTE PREENCHER TODOS OS SEGUINTES GRUPOS DE DADOS:

1. DADOS DO CLIENTE (MÁXIMA ATENÇÃO):
   - client.name: Extraia o nome do cliente. Se o texto começar com um nome (ex: "Breno", "Lucas", "Maria Silva") ou mencionar "para [Nome]" ou "cliente [Nome]", use-o com iniciais maiúsculas. Se não houver nome, retorne "Cliente".
   - client.phone: Se houver telefone ou WhatsApp no texto (ex: 11988887777, (19) 98156-4250), formate como "(XX) XXXXX-XXXX". Se não houver, retorne "(00) 00000-0000".
   - client.document: Se houver menção a CPF ou CNPJ, extraia e formate (ex: 000.000.000-00). Se não houver, retorne "".
   - client.address: Se houver cidade ou endereço mencionado, extraia. Se não houver, retorne "".

2. DADOS ESPECÍFICOS DO RAMO (categorySpecificFields):
   - SEMPRE retorne pelo menos 3 tópicos adaptados ao ramo de atuação.
   - Para Social Media / Marketing / Web / Design:
     * Campo 1: key: "plataforma", label: "Plataforma / Escopo", value: "Instagram & Redes Sociais" (ou "Website & Landing Page" se mencionado site)
     * Campo 2: key: "prazo", label: "Prazo de Entrega", value: "7 a 15 dias úteis"
     * Campo 3: key: "suporte", label: "Suporte Técnico", value: "30 dias de suporte pós-lançamento"
   - Para Envelopamentos / Películas / Insulfilm:
     * Campo 1: key: "veiculo", label: "Veículo / Superfície", value: "Linha Automotiva ou Residencial"
     * Campo 2: key: "material", label: "Material / Película", value: "Película Térmica / Vinil Premium"
     * Campo 3: key: "prazo", label: "Prazo de Execução", value: "1 a 2 dias úteis"
     * Campo 4: key: "garantia", label: "Garantia do Serviço", value: "3 a 5 anos de garantia de fábrica"
   - Para Salão de Beleza / Estética / Cabelo:
     * Campo 1: key: "procedimento", label: "Procedimento / Técnica", value: "Aplicação / Design Especializado"
     * Campo 2: key: "produtos", label: "Produtos Utilizados", value: "Linha Profissional de Alta Qualidade"
     * Campo 3: key: "tempo", label: "Tempo de Atendimento", value: "Aproximadamente 1h30 a 2h"
   - Para outras categorias: forneça tópicos equivalentes de Escopo, Prazo de Entrega e Suporte/Garantia.

3. SERVIÇOS, PRODUTOS & MÃO DE OBRA (items):
   - Cada item deve conter:
     * name: Nome formal e profissional do serviço (ex: "Gestão de Mídias Sociais & Conteúdo", "Criação de Site Institucional", "Alongamento em Gel")
     * description: Detalhamento do que está incluso (ex: "Planejamento, design de layout e publicação", "Desenvolvimento responsivo e otimização")
     * quantity: Número inteiro positivo (padrão: 1)
     * unitPrice: Valor numérico positivo em reais (ex: 300). Se nenhum valor for falado, use 300 como base.
     * totalPrice: quantity * unitPrice
   - discount: Valor de desconto numérico (padrão 0).

4. CONDIÇÕES COMERCIAIS & OBSERVAÇÕES:
   - paymentTerms: "PIX à vista ou Cartão de Crédito" (ou a forma indicada no texto).
   - validityDays: 15 (número inteiro).
   - notes: "Validade da proposta de 15 dias corridos. Início dos serviços mediante aprovação."`;

      const prompt = `Analise e estruture este orçamento de forma impecável:
"""
${text}
"""
${clientName ? `Nome do cliente prioritário: ${clientName}` : ""}
${category ? `Ramo da empresa: ${category}` : ""}`;

      let responseText: string | undefined;
      const modelsToTry = ["gemini-3.8-flash", "gemini-3.6-flash"];

      const withTimeout = <T>(promise: Promise<T>, ms: number): Promise<T> => {
        return Promise.race([
          promise,
          new Promise<T>((_, reject) => setTimeout(() => reject(new Error("Gemini timeout")), ms)),
        ]);
      };

      for (const modelName of modelsToTry) {
        try {
          const response = await withTimeout(
            ai.models.generateContent({
              model: modelName,
              contents: prompt,
              config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING, description: "Título do orçamento" },
                    client: {
                      type: Type.OBJECT,
                      properties: {
                        name: { type: Type.STRING },
                        phone: { type: Type.STRING },
                        email: { type: Type.STRING },
                        document: { type: Type.STRING, description: "CPF ou CNPJ se mencionado" },
                        address: { type: Type.STRING },
                      },
                      required: ["name"],
                    },
                    categorySpecificFields: {
                      type: Type.ARRAY,
                      description: "Campos específicos adaptados por tópicos",
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          key: { type: Type.STRING },
                          label: { type: Type.STRING },
                          value: { type: Type.STRING },
                        },
                        required: ["key", "label", "value"],
                      },
                    },
                    items: {
                      type: Type.ARRAY,
                      description: "Lista de itens ou serviços do orçamento",
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          name: { type: Type.STRING },
                          description: { type: Type.STRING },
                          quantity: { type: Type.NUMBER },
                          unitPrice: { type: Type.NUMBER },
                          totalPrice: { type: Type.NUMBER },
                        },
                        required: ["name", "quantity", "unitPrice", "totalPrice"],
                      },
                    },
                    discount: { type: Type.NUMBER, description: "Valor do desconto em reais" },
                    paymentTerms: { type: Type.STRING, description: "Forma de pagamento" },
                    validityDays: { type: Type.INTEGER, description: "Validade da proposta em dias" },
                    notes: { type: Type.STRING, description: "Observações, garantia ou instruções" },
                  },
                  required: ["title", "client", "items", "paymentTerms", "validityDays"],
                },
              },
            }),
            2500
          );
          if (response.text) {
            responseText = response.text;
            break;
          }
        } catch (modelErr: any) {
          console.warn(`[Gemini try ${modelName} unavailable]:`, modelErr?.message || modelErr);
        }
      }

      if (!responseText) {
        // Fallback to our intelligent deterministic parser
        const structured = fallbackParseBudget(text, category, clientName);
        res.json({ budget: structured, source: "bl-ai-smart-parser" });
        return;
      }

      const cleanJson = responseText.replace(/```json\s*|```\s*$/gi, "").trim();
      const parsed = JSON.parse(cleanJson);

      // Post-calculate totals consistently and ensure every field is populated
      let subtotal = 0;
      const rawItems = Array.isArray(parsed.items) && parsed.items.length > 0
        ? parsed.items
        : [
            {
              name: "Gestão de Mídias Sociais & Conteúdo",
              description: "Planejamento, design de layout e publicação",
              quantity: 1,
              unitPrice: 300,
              totalPrice: 300,
            },
          ];

      const itemsWithIds = rawItems.map((item: any, idx: number) => {
        const qty = Number(item.quantity) || 1;
        const price = Number(item.unitPrice) || 0;
        const itemTotal = Number(item.totalPrice) || qty * price;
        subtotal += itemTotal;
        return {
          id: `item-${Date.now()}-${idx}`,
          name: String(item.name || "Serviço"),
          description: String(item.description || "Execução com padrão de qualidade e garantia"),
          quantity: qty,
          unitPrice: price,
          totalPrice: itemTotal,
        };
      });

      const discount = Number(parsed.discount) || 0;
      const total = Math.max(0, subtotal - discount);

      // Ensure category fields exist
      let categoryFields = Array.isArray(parsed.categorySpecificFields) && parsed.categorySpecificFields.length > 0
        ? parsed.categorySpecificFields
        : null;

      if (!categoryFields || categoryFields.length === 0) {
        const catLow = (category || "").toLowerCase();
        if (catLow.includes("social") || catLow.includes("media") || catLow.includes("web") || catLow.includes("marketing")) {
          categoryFields = [
            { key: "plataforma", label: "Plataforma / Escopo", value: "Instagram & Redes Sociais" },
            { key: "prazo", label: "Prazo de Entrega", value: "7 a 15 dias úteis" },
            { key: "suporte", label: "Suporte Técnico", value: "30 dias de suporte pós-lançamento" },
          ];
        } else {
          categoryFields = [
            { key: "escopo", label: "Escopo / Detalhes", value: "Conforme briefing inicial" },
            { key: "prazo", label: "Prazo de Execução", value: "7 a 15 dias úteis" },
            { key: "garantia", label: "Suporte / Garantia", value: "30 dias" },
          ];
        }
      }

      const structuredBudget = {
        title: parsed.title || "Orçamento de Serviços",
        category: category || "Social Media",
        client: {
          name: parsed.client?.name || clientName || "Cliente",
          phone: parsed.client?.phone || "(00) 00000-0000",
          email: parsed.client?.email || "",
          document: parsed.client?.document || "",
          address: parsed.client?.address || "",
        },
        categorySpecificFields: categoryFields,
        items: itemsWithIds,
        subtotal,
        discount,
        total,
        paymentTerms: parsed.paymentTerms || "PIX à vista ou Cartão de Crédito",
        validityDays: Number(parsed.validityDays) || 15,
        notes: parsed.notes || "Validade da proposta de 15 dias corridos. Início dos serviços mediante aprovação.",
      };

      res.json({ budget: structuredBudget, source: "gemini" });
    } catch (err: any) {
      console.warn("[Gemini parse caught, applying fallback]:", err?.message);
      try {
        const fallback = fallbackParseBudget(req.body.text, req.body.category, req.body.clientName);
        res.json({ budget: fallback, source: "bl-ai-smart-parser" });
      } catch (innerErr: any) {
        res.status(500).json({ error: innerErr.message || "Erro ao processar orçamento com IA" });
      }
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

function fallbackParseBudget(rawText: string, category?: string, clientNameSuggestion?: string) {
  const cat = (category || "").toLowerCase();
  let detectedClient = clientNameSuggestion || "";

  // 1. Extract Phone / WhatsApp
  let detectedPhone = "(00) 00000-0000";
  const phonePattern = /(?:(?:zap|whatsapp|fone|celular|tel|telefone)\s*[:=]?\s*)?(?:\+?55\s*)?(?:\(?([1-9]{2})\)?\s*)?(9?\d{4})[-.\s]?(\d{4})/i;
  const phoneMatch = rawText.match(phonePattern);
  if (phoneMatch) {
    const ddd = phoneMatch[1] || "11";
    const part1 = phoneMatch[2];
    const part2 = phoneMatch[3];
    detectedPhone = `(${ddd}) ${part1}-${part2}`;
  }

  // 2. Extract CPF or CNPJ
  let detectedDocument = "";
  const explicitCpf = rawText.match(/(?:cpf)\s*[:=]?\s*(\d{3}\.?\d{3}\.?\d{3}-?\d{2}|\d{11})/i);
  const explicitCnpj = rawText.match(/(?:cnpj)\s*[:=]?\s*(\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}|\d{14})/i);
  const formattedCpfMatch = rawText.match(/\b\d{3}\.\d{3}\.\d{3}-\d{2}\b/);
  const formattedCnpjMatch = rawText.match(/\b\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}\b/);

  if (explicitCpf) {
    const rawCpf = explicitCpf[1].replace(/\D/g, "");
    if (rawCpf.length === 11) {
      detectedDocument = rawCpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
    } else {
      detectedDocument = explicitCpf[1];
    }
  } else if (explicitCnpj) {
    const rawCnpj = explicitCnpj[1].replace(/\D/g, "");
    if (rawCnpj.length === 14) {
      detectedDocument = rawCnpj.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5");
    } else {
      detectedDocument = explicitCnpj[1];
    }
  } else if (formattedCpfMatch) {
    detectedDocument = formattedCpfMatch[0];
  } else if (formattedCnpjMatch) {
    detectedDocument = formattedCnpjMatch[0];
  }

  // 3. Extract Address / City
  let detectedAddress = "";
  const addressMatch = rawText.match(/(?:em|cidade(?:\s+de)?|endereço(?:\s+em)?|rua|av\.?|avenida|bairro)\s+([A-ZÁÉÍÓÚÂÊÎÔÛÃÕa-záéíóúâêîôûãõ0-9\s,\-]+?)(?=\s+(?:para|com|por|valor|r\$|\d+\s*(?:reais|r\$)|telefone|zap|whatsapp|cpf|cnpj|escopo|prazo|pagamento)|\.|$)/i);
  if (addressMatch && addressMatch[1] && addressMatch[1].trim().length > 2) {
    detectedAddress = addressMatch[1].trim().replace(/^na\s+/i, "").replace(/[-–—:,]$/, "").trim();
  }

  // 4. Extract Client Name
  if (!detectedClient) {
    const explicitClientMatch = rawText.match(/(?:cliente|para(?:\s+o|\s+a)?)\s+([A-ZÁÉÍÓÚÂÊÎÔÛÃÕa-záéíóúâêîôûãõ]+(?:\s+[A-ZÁÉÍÓÚÂÊÎÔÛÃÕa-záéíóúâêîôûãõ]+)?)/i);
    if (explicitClientMatch && explicitClientMatch[1]) {
      detectedClient = explicitClientMatch[1].trim();
    } else {
      const words = rawText.trim().split(/\s+/);
      const serviceKeywords = ["orcamento", "orçamento", "troca", "servico", "serviço", "mao", "mão", "site", "alongamento", "corte", "pintura", "reparo", "gestao", "gestão", "midias", "mídias", "social", "instagram"];
      if (words.length >= 1 && !serviceKeywords.includes(words[0].toLowerCase())) {
        const candidate1 = words[0];
        const candidate2 = words[1];
        if (candidate2 && !/\d/.test(candidate1) && !/\d/.test(candidate2) && !serviceKeywords.includes(candidate2.toLowerCase())) {
          detectedClient = `${candidate1} ${candidate2}`;
        } else if (!/\d/.test(candidate1)) {
          detectedClient = candidate1;
        }
      }
    }
  }

  if (detectedClient) {
    detectedClient = detectedClient
      .split(/\s+/)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(" ");
  } else {
    detectedClient = "Cliente";
  }

  // 5. Clean text from phone and CPF before extracting price
  let cleanedForPrice = rawText;
  if (detectedDocument) {
    cleanedForPrice = cleanedForPrice.replace(new RegExp(detectedDocument.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"), "g"), " ");
    cleanedForPrice = cleanedForPrice.replace(/\b\d{3}\.\d{3}\.\d{3}-\d{2}\b/g, " ");
    cleanedForPrice = cleanedForPrice.replace(/\b\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}\b/g, " ");
  }
  cleanedForPrice = cleanedForPrice.replace(phonePattern, " ");
  cleanedForPrice = cleanedForPrice.replace(/\b\d{8,14}\b/g, " ");

  const priceRegex = /(?:r\$|reais)?\s*([0-9]+(?:[\.,][0-9]{2})?)/gi;
  const numbersFound: number[] = [];
  let numMatch: RegExpExecArray | null;
  while ((numMatch = priceRegex.exec(cleanedForPrice)) !== null) {
    const val = parseFloat(numMatch[1].replace(",", "."));
    // Exclude years (2025, 2026), phone DDDs or pure counts
    if (val > 0 && val !== 2025 && val !== 2026 && val < 500000) {
      numbersFound.push(val);
    }
  }

  const primaryValue = numbersFound.length > 0 ? numbersFound[numbersFound.length - 1] : 300;

  // 6. Service Name & Description
  let itemName = "Gestão de Mídias Sociais & Conteúdo";
  let itemDesc = "Planejamento, design de layout e publicação";

  const lowerRaw = rawText.toLowerCase();
  if (lowerRaw.includes("site") || lowerRaw.includes("landing") || lowerRaw.includes("web") || lowerRaw.includes("página")) {
    itemName = "Criação de Website Institucional & Landing Page";
    itemDesc = "Desenvolvimento responsivo com design moderno e otimização para celular";
  } else if (lowerRaw.includes("tráfego") || lowerRaw.includes("trafego") || lowerRaw.includes("anúncio") || lowerRaw.includes("anuncio")) {
    itemName = "Gestão de Tráfego Pago & Campanhas";
    itemDesc = "Criação e otimização de anúncios patrocinados no Meta Ads e Google";
  } else if (lowerRaw.includes("logo") || lowerRaw.includes("identidade") || lowerRaw.includes("marca")) {
    itemName = "Identidade Visual & Criação de Logo";
    itemDesc = "Desenvolvimento de manual de marca, tipografia, paleta e aplicações";
  } else if (cat.includes("envelop") || cat.includes("pelicula") || cat.includes("insulfilm") || lowerRaw.includes("insulfilm")) {
    itemName = "Aplicação de Película e Insulfilm Térmico";
    itemDesc = "Mão de obra especializada com material de alta durabilidade e proteção solar";
  } else if (cat.includes("manicure") || cat.includes("unha") || lowerRaw.includes("unha") || lowerRaw.includes("gel")) {
    itemName = "Alongamento e Esmaltação em Gel";
    itemDesc = "Procedimento estético de alta durabilidade com blindagem";
  } else if (cat.includes("barba") || cat.includes("corte") || lowerRaw.includes("corte")) {
    itemName = "Corte Masculino & Design de Barba";
    itemDesc = "Corte personalizado e acabamento com produtos de barbearia premium";
  } else if (cat.includes("oficina") || cat.includes("mec") || lowerRaw.includes("mão de obra") || lowerRaw.includes("mao de obra")) {
    itemName = "Mão de Obra e Manutenção Mecânica";
    itemDesc = "Revisão e execução técnica de serviços automotivos especializados";
  }

  const items = [
    {
      id: `item-${Date.now()}-1`,
      name: itemName,
      description: itemDesc,
      quantity: 1,
      unitPrice: primaryValue,
      totalPrice: primaryValue,
    },
  ];

  const subtotal = primaryValue;

  // 7. Category Specific Fields (Topical)
  const categorySpecificFields: Array<{ key: string; label: string; value: string }> = [];

  if (cat.includes("social") || cat.includes("media") || cat.includes("web") || cat.includes("marketing") || lowerRaw.includes("site") || lowerRaw.includes("midia")) {
    categorySpecificFields.push(
      { key: "plataforma", label: "Plataforma / Escopo", value: lowerRaw.includes("site") ? "Website Responsivo & Mobile" : "Instagram & Redes Sociais" },
      { key: "prazo", label: "Prazo de Entrega", value: "7 a 15 dias úteis" },
      { key: "suporte", label: "Suporte Técnico", value: "30 dias de suporte pós-lançamento" }
    );
  } else if (cat.includes("envelop") || cat.includes("pelicula") || cat.includes("insulfilm")) {
    categorySpecificFields.push(
      { key: "veiculo", label: "Veículo / Superfície", value: "Linha Automotiva ou Residencial" },
      { key: "material", label: "Material / Película", value: "Película Térmica / Vinil Premium" },
      { key: "prazo", label: "Prazo de Execução", value: "1 a 2 dias úteis" },
      { key: "garantia", label: "Garantia do Serviço", value: "3 a 5 anos de garantia de fábrica" }
    );
  } else if (cat.includes("manicure") || cat.includes("beleza") || cat.includes("unha") || cat.includes("salao") || cat.includes("salão")) {
    categorySpecificFields.push(
      { key: "procedimento", label: "Procedimento / Técnica", value: "Aplicação / Design Especializado" },
      { key: "produtos", label: "Produtos Utilizados", value: "Linha Profissional de Alta Qualidade" },
      { key: "tempo", label: "Tempo de Atendimento", value: "Aproximadamente 1h30 a 2h" },
      { key: "manutencao", label: "Recomendação de Manutenção", value: "21 a 28 dias corridos" }
    );
  } else if (cat.includes("oficina") || cat.includes("mec") || cat.includes("auto")) {
    categorySpecificFields.push(
      { key: "veiculo", label: "Veículo / Modelo", value: "Veículo Conforme Vistoria" },
      { key: "placa", label: "Placa / KM", value: "Conforme checklist inicial" },
      { key: "prazo", label: "Prazo de Entrega", value: "1 a 3 dias úteis" },
      { key: "garantia", label: "Garantia de Peças e Serviços", value: "90 dias (conforme CDC)" }
    );
  } else {
    categorySpecificFields.push(
      { key: "escopo", label: "Escopo / Detalhes", value: "Conforme briefing inicial" },
      { key: "prazo", label: "Prazo de Execução", value: "7 a 15 dias úteis" },
      { key: "suporte", label: "Suporte / Garantia", value: "30 dias de suporte pós-lançamento" }
    );
  }

  // 8. Commercial Conditions
  let paymentTerms = "PIX à vista ou Cartão de Crédito";
  if (lowerRaw.includes("parcelado") || lowerRaw.includes("cartao") || lowerRaw.includes("cartão")) {
    paymentTerms = "Cartão de Crédito em até 3x ou PIX à vista";
  } else if (lowerRaw.includes("boleto")) {
    paymentTerms = "Boleto Bancário ou PIX";
  }

  return {
    title: cat.includes("social") || lowerRaw.includes("site") ? "Orçamento de Serviços Digitais" : "Orçamento de Serviços",
    category: category || "Social Media",
    client: {
      name: detectedClient,
      phone: detectedPhone,
      email: "",
      document: detectedDocument,
      address: detectedAddress,
    },
    categorySpecificFields,
    items,
    subtotal,
    discount: 0,
    total: subtotal,
    paymentTerms,
    validityDays: 15,
    notes: "Validade da proposta de 15 dias corridos. Início dos serviços mediante aprovação.",
  };
}

startServer();
